package neu.csye7374.src.Strategy_Pattern;

public enum DiscountStrategy {
	NONE,
	EmployeeDiscount,
	StudentDiscount
}
