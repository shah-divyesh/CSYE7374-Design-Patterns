package neu.csye7374.src;

public interface BookStoreAPI {
	void addBooks();
	void addEmployees();
	void sortBooks();
	void sortEmployees();
}
