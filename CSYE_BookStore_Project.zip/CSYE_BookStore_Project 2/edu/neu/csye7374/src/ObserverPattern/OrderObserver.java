package neu.csye7374.src.ObserverPattern;

public interface OrderObserver {

	void updated(Order order); 
}
