package neu.csye7374.src.Builder;

public interface BuilderAPI<T> {
	T build();
}
