package neu.csye7374.src;

public interface BookAPI {
	String bookDescription();
	Object getBookAuthor();
	int noOfBooksPublished();
	double getBookPrice();
}
