package neu.csye7374.src.State_Pattern;

public interface BookStoreStateAPI {
	void state_Open();
	void state_Close();
	void state_Stock();
}
