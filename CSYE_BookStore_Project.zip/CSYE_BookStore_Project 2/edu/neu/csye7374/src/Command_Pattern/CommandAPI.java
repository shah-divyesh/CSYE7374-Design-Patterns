package neu.csye7374.src.Command_Pattern;

public interface CommandAPI {
	String execute();
}

